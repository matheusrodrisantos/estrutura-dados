
package listaencadeada;

public class Node {
    
    String element;
    Node next;
    
    //Builders
    Node(String n){
        element = n;
    }
    
    
    
    //Getters
    public String getElement(){
        return element;
    }
    public Node getNext(){
        return next;
    }
    
    //setters
    public void setElement(String e){
        element = e;
    }
    public void setNext(Node n){
        next = n;
    }
    
}
