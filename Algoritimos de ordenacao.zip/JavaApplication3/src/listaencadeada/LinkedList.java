/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package listaencadeada;

public class LinkedList {
    
    Node head; //head e tail sao variaveis de referencia que guardam endereços
    Node tail;
    int size; //tamanho da lista
    
    // Inserçao no inicio
    public void insertFirst(){
        Node novo = new Node("nome");
        if(size == 0){
            head = novo;
            tail = novo;
            size++;
        }else{
            novo.setNext(head);
            head = novo;
            size++;
        }
    }
    
    public void insertLast(String n){
        Node novo = new Node(n);
        if (size==0){
            head = novo;
            tail = novo;
            size++;
        }else{
            tail.setNext(novo);
            tail = novo;
            size++;
        }
    }
    
    public void removeFirst(){
        if(size == 0){
            System.out.println("Fila Vazia!!");
        }else{
            head = head.getNext();
            size--;
        }
    }
    
    public void removeLast(){
        if(size == 0){
            System.out.println("Fila Vazia!!");
        }else if(size == 1){
            head = null;
            tail = null;
            size = 0;
        }else{
            Node penultimo;
            penultimo = head;
            while(penultimo.getNext() != tail){
                penultimo = penultimo.getNext();
            }
            penultimo.setNext(null);
            tail = penultimo;
        }
    }
    
    public void printLista(){
        if(size==0){
            System.out.println("Fila Vazia!!");
        }else{
            Node current;
            current = head;
            while(current != null){
                System.out.println(current.getElement());
                current = current.getNext();
            }
        }
    }
    
}
