/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package listaencadeada;

import java.util.Scanner;

public class ListaEncadeada {
    
    public static void main(String args[]){
        
        int op = 0;
        LinkedList fila = new LinkedList();
        Scanner en = new Scanner(System.in);
        while(op !=4){
            System.out.println("Deseja:");
            System.out.println("1 - Adicionar cliente na fila");
            System.out.println("2 - Atender cliente");
            System.out.println("3 - Mostrar fila");
            System.out.println("4 - Sair");
            op = en.nextInt();
            switch (op){
                case 1:
                    System.out.println("Nome do cliente que entrou na fila?");
                    fila.insertLast(en.next());
                    System.out.println("");
                    break;
                case 2: 
                    fila.removeFirst();
                    System.out.println("");
                    break;
                case 3:
                    System.out.println("Fila:");
                    fila.printLista();
                    System.out.println("");
                    break;
                default:
                    System.out.println("");
            }
        }            
    }   
}
