package Trabalho2;
import static Trabalho2.Ordenacao.*;
public class TesteOrd1 {
    public static void main(String args[]){
        
        int[] T1 = {762,52,123,45,10,2,1544,982,565,140,265,396};
        int[] T2 = {762,52,123,45,10,2,1544,982,565,140,265,396}; 
        int[] T3 = {762,52,123,45,10,2,1544,982,565,140,265,396};
        int[] T4 = {762,52,123,45,10,2,1544,982,565,140,265,396};
        
        BubbleSort(T1);
        InsertionSort(T2);
        SelectionSort(T3);
        MergeSort(0,T4.length,T4);
        
        System.out.print("Resultado BubbleSort: ");
        for(int i=0;i<12;i++){
            System.out.print(T1[i]+" ");
        }
        System.out.println(" ");
        
        System.out.print("Resultado InsertionSort: ");
        for(int i=0;i<12;i++){
            System.out.print(T2[i]+" ");
        }
        System.out.println(" ");
        
        System.out.print("Resultado SelectionSort: ");
        for(int i=0;i<12;i++){
            System.out.print(T3[i]+" ");
        }
        
        System.out.println(" ");
        System.out.print("Resultado MargeSort: ");
        for(int i=0;i<12;i++){
            System.out.print(T3[i]+" ");
        }
    }
}
