package Trabalho2;

public class BTreeNode {

    BTreeNode parent;
    BTreeNode left;
    BTreeNode right;
    String element;
    
    // Getters
    BTreeNode getParent(){return parent;}
    BTreeNode getLeft(){return left;}
    BTreeNode getRight(){return right;}
    String getElement(){return element;}
   
    //Setters  
    void setParent (BTreeNode p){parent = p;}
    void setLeft (BTreeNode l){left = l;}
    void setRight (BTreeNode r){right = r;}
    void setElement (String e){element = e;}
    
    //Builders
    BTreeNode(BTreeNode p, BTreeNode l, BTreeNode r, String e){
        parent = p;
        left = l;
        right = r;
        element = e;
    }
    
    //Metodos isExternal, isInternal, isRoot, Depth e Height
    boolean isExternal(){
        if(this.getLeft()==null && this.getRight()==null){
            return true;
        } else {
            return false; 
        }
    }
    
    boolean isInternal(){
        if(this.getLeft()!=null || this.getRight()!=null){
            return true;
        } else {
            return false;
        }
    }
    
    boolean isRoot(){
        if(this.getParent()==null){ 
            return true;
        } else{
            return false;
        }
    }
    
    int Depth(){
        if(this.isRoot()==true){
            return 0;
        }else{
            return 1+this.getParent().Depth();
        }
    }
    
    int Height(){
        if(this.isExternal()==true){
            return 0;
        }else{ 
            int H;
            if(this.getLeft().Height()>this.getRight().Height()){
                H = this.getLeft().Height();
            }else{
                H = this.getRight().Height();
            }
            return 1+H;
        }
    }
}

