package Trabalho2;

public class Ordenacao {
    
    public static void BubbleSort(int[] A){
        int N = A.length;
        int temp;
        for(int i=0; i<N ;i++){
            for (int j=i; j<N ;j++){
                if(A[i]>A[j]){
                    temp = A[i];
                    A[i] = A[j];
                    A[j] = temp;
                }
            }
        }
    }
    
    public static void InsertionSort(int[] A){ 
        int N = A.length;
        for(int i=1; i<N ;i++){
            int x = A[i];
            int j;
            for (j=i; j>0 && (x<A[j-1]) ;j--){
                A[j] = A[j-1];
            }     
            A[j] = x;
        }
    }
    
    public static void SelectionSort(int[] A){
        int N = A.length;
        for(int i=0; i<N ;i++){
            int menor = A[i];
            int aux=0;
            for(int j=i; j<N ;j++){
                if(A[j]<=menor){
                    menor = A[j];
                    aux = j;
                }
            }
            A[aux] = A[i];
            A[i] = menor;
        }
    }
    
    public static void MergeSort(int inicio, int fim, int [] A){
        if(inicio < fim - 1){
            int meio = (inicio + fim) / 2;
            MergeSort(inicio, meio, A);
            intercala(A, inicio, meio, fim);
        }
    }        
    private static void intercala(int [] A, int inicio, int meio, int fim){
       int novoVetor[] = new int[fim - inicio];
       int i = inicio;
       int m = meio;
       int pos = 0;
     while(i <  meio && m < fim){
         if(A[i]<A[m]){
             novoVetor[pos] = A[i];
             pos = pos + 1;
             i = i + 1;
         }
         else{
             novoVetor[pos] = A[m];
             pos = pos + 1;
             m = m + 1;
         }
     }  
     while(i < meio){
         novoVetor[pos] = A[i];
         pos = pos + 1;
         i = i + 1;
     }   
     while(m < fim){
         novoVetor[pos] = A[m];
         pos = pos + 1;
         m = m + 1;
     }   
    for(pos = 0, i = inicio; i<fim; i++, pos++){
        A[i] = novoVetor[pos];
    }
  }



    
}
