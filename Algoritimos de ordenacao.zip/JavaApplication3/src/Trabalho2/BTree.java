package Trabalho2;

public class BTree {
    
    BTreeNode root;
    int size = 0;
    int cont = 0;
    
    //Contrutor
    BTree(){}
    
    //Setter e Getter do root
    void setRoot(BTreeNode r){root = r;}
    BTreeNode getRoot(){return root;}
 
    //Métodos de caminhamento
    void Preorder(BTreeNode v){ // v e d 
        //visita
        System.out.print(v.getElement()+" ");
        cont++;
        if(cont == this.Size()){
            System.out.println(" ");
            cont = 0;
        }
        //esquerda
        if (v.getLeft() != null){
            Preorder(v.getLeft());
        }
        //direita
        if (v.getRight()!= null){
            Preorder(v.getRight());
        } 
    }
    
    void Posorder(BTreeNode v){ // e d v 
        //esquerda
        if (v.getLeft() != null){
            Posorder(v.getLeft());
        }
        //direita
        if (v.getRight()!= null){
            Posorder(v.getRight());
        }
        //visita
        System.out.print(v.getElement()+" ");
        cont++;
        if(cont == this.Size()){
            System.out.println(" ");
            cont = 0;
        }
    }
    
    void Inorder(BTreeNode v){ // e v d
        //esquerda
        if (v.getLeft() != null){
            Inorder(v.getLeft());
        }
        //visita
        System.out.print(v.getElement()+" ");
        cont++;
        if(cont == this.Size()){
            System.out.println(" ");
            cont = 0;
        }
        //direita
        if (v.getRight()!= null){
            Inorder(v.getRight());
        } 
    }
    
    //Método auxiliar do size
    void ContSize(BTreeNode v){ // e v d 
        //esquerda
        if (v.getLeft() != null){
            ContSize(v.getLeft());
        }
        //soma
        size++;
        //direita
        if (v.getRight()!= null){
            ContSize(v.getRight());
        } 
    }
    
    //Retorna o tamanho da arvore
    int Size(){ // v e d
        size=0;
        ContSize(this.getRoot());
        return size;
    }
    
    //Verefica se a arvore esta vazia
    boolean isEmpty(){
        if(size == 0){
            System.out.println("A arvore esta vazia!");
            return true;
        } else {
            System.out.println("A arvore não esta vazia");
            System.out.println("Tamanho: "+size);
            return false;
        }
    }
}

