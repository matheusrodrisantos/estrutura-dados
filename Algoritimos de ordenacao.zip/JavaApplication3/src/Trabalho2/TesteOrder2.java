package Trabalho2;
import static Trabalho2.Ordenacao.*;
import java.util.Random;
/**
 * @author matheus
 * 
 * Parte II - Experimentos e comparação de Desempenho
Criar uma classe TesteOrd2 e testar os métodos de ordenação para as 
* seguintes quantidades de elementos aleatoriamente gerados: 100000, 200000, 300000, 500000 e 1000000;
Medir o tempo de execução de cada método e criar uma tabela e gráfico comparativo;
Procure analisar o desempenho empírico de cada um e concluir o porquê de cada desempenho.
* 
 */
public class TesteOrder2 {
    
    public static int[] gerarAleatorio(int[] a)
    {
        int tam=a.length;
        Random r = new Random();
        for (int i = 0; i < tam-1; i++) 
        {
            a[i] = r.nextInt(100000);
        }  
        return a; 
    }

    public static void main(String args[]){
        int[] teste1 = new int[100000];
        int[] teste2 = new int[200000];
        int[] teste3= new int[300000];
        int[] teste4= new int[500000];
        int[] teste5 = new int[1000000];    
        
        gerarAleatorio(teste1);
       /*
        gerarAleatorio(teste2);
        gerarAleatorio(teste3);
        gerarAleatorio(teste4);
        gerarAleatorio(teste5);
        */
        
        //BubbleSort(teste1);
        //InsertionSort(teste1);
        //SelectionSort(teste1);
        MergeSort(0,teste1.length,teste1 );
        
        /*
        BubbleSort(teste2);
        InsertionSort(teste2);
        SelectionSort(teste2);
        MergeSort(0,teste2.length,teste2);
        
        
        BubbleSort(teste3);
        InsertionSort(teste3);
        SelectionSort(teste3);
        MergeSort(0,teste3.length,teste3);
        
        BubbleSort(teste4);
        InsertionSort(teste4);
        SelectionSort(teste4);
        MergeSort(0,teste4.length,teste4);
        
        BubbleSort(teste5);
        InsertionSort(teste5);
        SelectionSort(teste5);
        MergeSort(0,teste5.length,teste5);
        */
        
        System.out.print("Resultado BubbleSort: ");
        for(int i=0;i<teste1.length-1;i++){
            System.out.println(teste1[i]+" ");
            
        }
    } 
}
