package Trabalho2;
public class BTreeTeste {
    
    public static void main(String args[]){
        
        BTree tree = new BTree();
        
        BTreeNode b = new BTreeNode(null, null, null, "B");
        tree.setRoot(b);
        BTreeNode a = new BTreeNode(b, null, null, "A");
        b.setLeft(a);
        BTreeNode d = new BTreeNode(b, null, null, "D");
        b.setRight(d);
        BTreeNode c = new BTreeNode(d, null, null, "C");
        d.setLeft(c);
        BTreeNode e = new BTreeNode(d, null, null, "E");
        d.setRight(e);
      
        
        System.out.print("Caminhamento preorder: ");
        tree.Preorder(b);
        System.out.print("Caminhamento inorder: ");
        tree.Inorder(b);
        System.out.print("Caminhamento posorder: ");
        tree.Posorder(b);
        
        System.out.println("Profundidade de A: "+a.Depth());
        System.out.println("Altura de A: "+a.Height());
        System.out.println("Profundidade de B: "+b.Depth());
        System.out.println("Altura de B: "+b.Height());
        System.out.println("Profundidade de C: "+c.Depth());
        System.out.println("Altura de C: "+c.Height());
        System.out.println("Profundidade de D: "+d.Depth());
        System.out.println("Altura de D: "+d.Height());
        System.out.println("Profundidade de E: "+e.Depth());
        System.out.println("Altura de E: "+e.Height());
        
    } 
}

