
package ListaEncadeada2;

public class DLNode {
    
    String element;
    DLNode next;
    DLNode fore;
    
    //Builders
    DLNode(String n){element = n;}
   
    //Getters
    public String getElement(){return element;}
    public DLNode getNext(){return next;}
    public DLNode getFore(){return fore;}
    
    //setters
    public void setElement(String e){element = e;}
    public void setNext(DLNode n){next = n;}
    public void setFore(DLNode n){fore = n;}
}
