package ListaEncadeada2;

import java.util.Scanner;

public class FilaEncadeada {
    
    public static void main(String args[]){
        
        int op = 0;
        DLinkedList fila = new DLinkedList();
        Scanner en = new Scanner(System.in);
        while(op !=4){
            System.out.println("Deseja:");
            System.out.println("1 - Adicionar cliente na fila");
            System.out.println("2 - Atender cliente");
            System.out.println("3 - Mostrar fila");
            System.out.println("4 - Sair");
            op = en.nextInt();
            switch (op){
                case 1:
                    System.out.println("Nome do cliente que entrou na fila?");
                    fila.insertLast(en.next());
                    System.out.println("");
                    break;
                case 2: 
                    fila.removeFirst();
                    System.out.println("");
                    break;
                case 3:
                    fila.printFila();
                    System.out.println("");
                    break;
                default:
                    System.out.println("");
            }
        }            
    }   
}
