package ListaEncadeada2;

public class DLinkedList {
    
    DLNode head; //head e tail sao variaveis de referencia que guardam endereços
    DLNode tail;
    int size=0; //tamanho da lista
    
    // Inserçao no inicio
    public void insertFirst(String n){
        DLNode novo = new DLNode(n);
        if(size == 0){
            head = novo;
            tail = novo;
        }else{
            novo.setNext(head);
            head.setFore(novo);
            head = novo; 
        }
        size++;
    }
    public void insertLast(String n){
        DLNode novo = new DLNode(n);
        if (size==0){
            head = novo;
            tail = novo;
        }else{
            tail.setNext(novo);
            novo.setFore(tail);
            tail = novo;
        }
        size++;
    }
    public void removeFirst(){
        if(size == 0){
            System.out.println("Fila Vazia!!");
        }else if(size == 1){
            head = null;
            tail = null;
            size = 0;
        }else{
            head = head.getNext();
            head.setFore(null);
            size--;
        }
    }
    public void removeLast(){
        if(size == 0){
            System.out.println("Fila Vazia!!");
        }else if(size == 1){
            head = null;
            tail = null;
            size = 0;
        }else{
            tail = tail.getFore();
            tail.setNext(null);
            size--;
        }
    }
    public void printFila(){
        if(size==0){
            System.out.println("Fila Vazia!!");
        }else{
            System.out.println("Fila:");
            DLNode current;
            current = head;
            while(current != null){
                System.out.println(current.getElement());
                current = current.getNext();
            }
        }
    }
    
    public void printPilha(){
        if(size==0){
            System.out.println("Pilha Vazia!!");
        }else{
            System.out.println("Pilha:");
            DLNode current;
            current = head;
            while(current != null){
                System.out.println(current.getElement());
                current = current.getNext();
            }
        }
    }
}
