package ListaEncadeada2;

import java.util.Scanner;

public class PilhaEncadeada {
    
    public static void main(String args[]){
        
        int op = 0;
        DLinkedList pilha = new DLinkedList();
        Scanner en = new Scanner(System.in);
        while(op !=4){
            System.out.println("Deseja:");
            System.out.println("1 - Adicionar cliente na pilha");
            System.out.println("2 - Atender cliente");
            System.out.println("3 - Mostrar pilha");
            System.out.println("4 - Sair");
            op = en.nextInt();
            switch (op){
                case 1:
                    System.out.println("Nome do cliente que entrou na pilha?");
                    pilha.insertLast(en.next());
                    System.out.println("");
                    break;
                case 2: 
                    pilha.removeLast();
                    System.out.println("");
                    break;
                case 3:
                    pilha.printPilha();
                    System.out.println("");
                    break;
                default:
                    System.out.println("");
            }
        }            
    }  
}
