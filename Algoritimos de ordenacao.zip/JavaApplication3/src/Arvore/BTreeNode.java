package Arvore;

public class BTreeNode {

    BTreeNode parent;
    BTreeNode left;
    BTreeNode right;
    String element;
    
    // Getters
    BTreeNode getParent(){
        return parent;
    }
    BTreeNode getLeft(){
        return left;
    }
    BTreeNode getRight(){
        return right;
    }
    String getElement(){
        return element;
    }
    
    
    //Setters  
    void setParent (BTreeNode p){
        parent = p;
    }
    void setLeft (BTreeNode l){
        left = l;
    }
    void setRight (BTreeNode r){
        right = r;
    }
    void setElement (String e){
        element = e;
    }
    
    //Builders
    BTreeNode(BTreeNode p, BTreeNode l, BTreeNode r, String e){
        parent = p;
        left = l;
        right = r;
        element = e;
    }
    
}
