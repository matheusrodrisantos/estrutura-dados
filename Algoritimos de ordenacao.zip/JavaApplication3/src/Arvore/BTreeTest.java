
package Arvore;

public class BTreeTest {
    
    public static void main(String args[]){
        
        BTree tree = new BTree();
        
        BTreeNode p = new BTreeNode(null, null, null, "Peixe");
        tree.setRoot(p);
        
        BTreeNode f = new BTreeNode(p, null, null, "Fravio");
        
        BTreeNode l = new BTreeNode(p, null, null, "Lucas");
        
        p.setLeft(f);
        p.setRight(l);
        tree.Preorder(p);  
        tree.Posorder(p);
    } 
}
