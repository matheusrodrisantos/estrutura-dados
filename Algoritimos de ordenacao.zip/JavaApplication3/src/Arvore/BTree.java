package Arvore;

public class BTree {
    
    BTreeNode root;
    int size;
    
    BTree(){
   
    }
    
    void setRoot(BTreeNode r){
        root = r;
    }
     
    void Preorder(BTreeNode v){ // v e d 
        //visita
        System.out.println(v.getElement()+"");
        //esquerda
        if (v.getLeft() != null){
            Preorder(v.getLeft());
        }
        //direita
        if (v.getRight()!= null){
            Preorder(v.getRight());
        }
        
    }
    
    void Posorder(BTreeNode v){ // e d v 
        //esquerda
        if (v.getLeft() != null){
            Preorder(v.getLeft());
        }
        //direita
        if (v.getRight()!= null){
            Preorder(v.getRight());
        }
        //visita
        System.out.println(v.getElement()+"");
        
    }
    
}
