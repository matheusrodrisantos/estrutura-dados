/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication3;

/**
 *
 * @author aluno4
 */
public class TesteConta {
    
    public static void main(String arg[]){
        
     Conta c2 = new Conta(2,(float)200.00);
     Conta c1 = new Conta();
     
     c1.setNumero(1);
     c1.setSaldo((float)100000.00);
 
     System.out.println(c1.getNumero());
     System.out.println(c1.getSaldo());
     
     Conta lits[] = new Conta[3];
        
    }
}
