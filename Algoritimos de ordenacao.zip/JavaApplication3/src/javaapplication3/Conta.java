/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication3;

public class Conta {
    
    int numero; //São os atributos
    float saldo;
    
    //Builders (construtores)
    Conta (int nu, float sal){
        numero = nu;
        saldo = sal;
    }
    Conta(){
        //contrutores sempre tem o mesmo nome da classe
    } 
  
    //Getters
    int getNumero(){        // 'int' - indica o tipo do return
        return numero;
    }
    float getSaldo(){
        return saldo;
    }
    
    //Setters
    void setNumero(int n){
        numero = n;
    }
    void setSaldo(float n){
        saldo = n;
    }   
}
