/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication3;

import java.util.Scanner;
import java.util.Random;

public class TesteEx3_1 {
    public static void main(String[] args) {
        
        Scanner en = new Scanner(System.in);                    //1
        Random gerador = new Random();                          //1
        
        int n;                                                  //1
        
        n = en.nextInt();                                       //1
        long tempoInicial = System.currentTimeMillis();        
        
        int X[] = new int[n];                                   //1+1
        float A[] = new float[n];                               //1+1
        
        for(int i=0;i<n;i++){                                   //3n+2
            X[i] = gerador.nextInt(10);                         //2n
        }
        
        for(int i=0;i<n;i++){                                   //3n+2
            int a = 0;                                          //n
            for(int j=0;j<=i;j++){                              //n(n+1)/2*3 + n
                a = a + X[j];                                   //n(n+1)/2*3                   
            }
            A[i] = (float)a/(i+1);                              //3n
            System.out.print(A[i]+" ");                         //2n
        }                                                       //F(n)=3n^2+18n+12           
        System.out.println("\nO metodo executou em " + (System.currentTimeMillis() - tempoInicial)+" milissegundos");
    }
}
