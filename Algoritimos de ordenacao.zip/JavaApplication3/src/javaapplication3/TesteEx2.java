// Algoritmo com int funciona até 73!
// Algoritmo com long funciona até 6200 (valor aproximado)!



package javaapplication3;

import java.util.Scanner;

public class TesteEx2 {

    public static void main(String arg[]) {

        Scanner en = new Scanner(System.in);                           //1
        int valores[] = new int[5];                                    //1
        TesteEx2 teste = new TesteEx2();                               //1

        System.out.println("Entre com os elementos do array");         //1
        
        
        for (int i = 0; i < 5; i++) {                                  //(1+n+1+n) = 2*n+2
            valores[i] = en.nextInt();                                 //(1+1)*n   = 2*n
        }
        
        for (int j = 0; j < 5; j++) {                                  //(1+n+1+n) = 2*n+2
            teste.funcao_potencia(valores[j]);                         //n*(5*n+4) = 5*n^2+4*n
        }                                                              //-------------------------
    }                                                                            //= 5*n^2+10*n+8
                                                                                 // O(n) = n^2
    
    void funcao_potencia(int base) {
        long res = 1;                                                  //1
        
        System.out.println(base + " elevado a " + 0 + " = " + res);    //1
   
        for (int i = 1; i <= 5; i++) {                                 //2+2*n
            res = res * base;                                          //2*n
            System.out.println(base + " elevado a " + i + " = " + res);//1*n
        }                                                              //----------
    }                                                                  //5*n+4
}   
