/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication3;

/**
 *
 * @author aluno4
 */
public class Cliente {
    
    //São os atributos
    String nome;
    
    //Builders (construtores)
    Cliente (String no){
        nome = no;
    }
    Cliente(){
        //contrutores sempre tem o mesmo nome da classe
    } 
  
    //Getters
    String getNome(){
        return nome;
    }
    
    //Setters
    void setNome(String no){
        nome = no;
    }    
}
