package javaapplication3;

import java.util.Scanner;

public class TesteEx1 {
    
    public static void main(String arg[]){
        
     Scanner en = new Scanner(System.in);
    
     Cliente fila[] = new Cliente[5];
     fila[0] = new Cliente("Vazio");
     fila[1] = new Cliente("Vazio");
     fila[2] = new Cliente("Vazio");
     fila[3] = new Cliente("Vazio");
     fila[4] = new Cliente("Vazio");

     int op;

     int i = 0;
     while(i < 6){
        if(i == 5){
            System.out.println(" ");
            System.out.println("Fila Cheia!!");
            System.out.println("2 - Atender cliente");
            System.out.println("3 - Ver fila");
            op = en.nextInt();
            switch (op){
            case 2:
                String nome = fila[0].getNome();
                System.out.println("Cliente "+nome+" foi atendido e saiu da fila");
                fila[0].setNome(" ");
                for(int j = 1;j<5;j++){
                    fila[j-1].setNome(fila[j].getNome());
                }
                fila[4].setNome("Vazio");
                i--;
                break;
            case 3:
                for(int j =0;j<5;j++){
                System.out.println(fila[j].getNome());
                }
                break;
            default:
                System.out.println("");
            }
        }else{
            System.out.println("");
            System.out.println("Deseja:");
            System.out.println("1 - Adicionar cliente na fila");
            System.out.println("2 - Atender cliente");
            System.out.println("3 - Mostrar fila");
            op = en.nextInt();
            switch (op){
                case 1:
                    String aux;
                    System.out.println("Nome do cliente que entrou na fila?");
                    aux = en.next();
                    fila[i].setNome(aux);
                    i++;
                    break;
                case 2:
                    String nome = fila[0].getNome();
                    if(nome.equals("Vazio")){
                        System.out.println("Não existem clientes na fila");
                    }else{
                        System.out.println("Cliente "+nome+" foi atendido e saiu da fila");
                        fila[0].setNome(" ");
                        for(int j =1;j<5;j++){
                            fila[j-1].setNome(fila[j].getNome());
                        }
                        fila[4].setNome("Vazio");
                        i--;
                    }   
                    break;
                case 3:
                    for(int j =0;j<5;j++){
                        System.out.println("");
                        System.out.println(fila[j].getNome());
                    }
                    break;
                default:
                    System.out.println("");
            }
        }
     }    
    }   
}
