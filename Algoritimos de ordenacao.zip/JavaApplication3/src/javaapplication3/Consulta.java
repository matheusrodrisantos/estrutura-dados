package javaapplication3;
public class Consulta {
    public static void main(String[] args) {
        
    }
}
